package com.ssm.framework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
