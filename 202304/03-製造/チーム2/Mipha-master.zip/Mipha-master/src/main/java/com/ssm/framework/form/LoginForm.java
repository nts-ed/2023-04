package com.ssm.framework.form;

import lombok.Data;

@Data
public class LoginForm {
	//社員ID
	private String employeeId;
	
	//パスワード
	private String password;
	

}
